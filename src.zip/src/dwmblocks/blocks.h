//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/ /*Command*/	  /*Update Interval*/	/*Update Signal*/
	{"", "~/script/statusbar/network",		 20,		          2},
	
	{"", "~/script/statusbar/memory",	 2,		              1},

	{"", "~/script/statusbar/cpu",            2,                           1},

	{"", "~/script/statusbar/volume",     20,		              30},

	{"", "~/script/statusbar/clock",	     60,	              0},
};

//sets delimeter between status commands. NULL character ('\0') means no delimeter.
static char delim = '|';
